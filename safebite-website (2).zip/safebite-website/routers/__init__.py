from .auth import router as auth_router
from .profile import router as profile_router
from .scanner import router as scanner_router
from .ai_assistant import router as ai_router

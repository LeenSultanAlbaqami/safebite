"""
SafeBite — AI Assistant Router
Integrates Groq LLM (Llama-3) to provide expert food safety advice.
Processes /ai/ask requests for the chatbot UI.
"""

import os
from fastapi import APIRouter
from groq import Groq
from schemas import ChatRequest, ChatResponse
from dotenv import load_dotenv

load_dotenv()

router = APIRouter(prefix="/ai", tags=["AI Assistant"])

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
_client: Groq | None = None

def _get_client() -> Groq:
    global _client
    if _client is None:
        _client = Groq(api_key=GROQ_API_KEY)
    return _client

SYSTEM_PROMPT = "You are SafeBite AI — expert in food safety, allergens, and health. 🛡️"

@router.post("/ask", response_model=ChatResponse)
async def ask_ai(body: ChatRequest):
    """Sends user queries to the LLM and returns formatted safety advice."""
    try:
        client = _get_client()
        completion = client.chat.completions.create(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user",   "content": body.message},
            ],
            model="llama-3.3-70b-versatile",
            temperature=0.7,
            max_tokens=800,
        )
        return ChatResponse(status="success", reply=completion.choices[0].message.content)
    except Exception:
        return ChatResponse(status="error", reply="I am currently offline. Please try again soon! 🛡️")
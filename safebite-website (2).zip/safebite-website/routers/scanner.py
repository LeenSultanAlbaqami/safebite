from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from database.connection import get_db
from security import get_current_user
from models import User, Product, ScanHistory, Allergy, ProductAllergy
from typing import List

router = APIRouter(prefix="/scanner", tags=["Scanning System"])

ALLERGY_KEYWORDS = {
    "Dairy": ["milk", "cheese", "cream", "lactose", "butter", "whey", "casein", "yogurt", "ghee", "حليب", "جبن", "قشطة", "زبدة", "لاكتوز", "سمن"],
    "Gluten": ["wheat", "barley", "flour", "gluten", "rye", "oats", "semolina", "malt", "قمح", "دقيق", "شعير", "جلوتين", "شوفان", "سميد"],
    "Peanuts": ["peanut", "arachis", "فول سوداني", "زبدة فول سوداني"],
    "Tree Nuts": ["almond", "walnut", "cashew", "hazelnut", "pistachio", "pecan", "brazil nut", "macadamia", "لوز", "جوز", "كاجو", "فستق", "بندق"],
    "Eggs": ["egg", "albumen", "yolk", "mayonnaise", "بيض", "صفار", "بياض", "مايونيز"],
    "Soy": ["soy", "soya", "tofu", "lecithin", "edamame", "صويا", "توفو"],
    "Fish": ["fish", "tuna", "salmon", "cod", "anchovy", "سمك", "تونا", "سلمون"],
    "Shellfish": ["shrimp", "prawn", "crab", "lobster", "mussel", "oyster", "روبيان", "جمبري", "قبقب", "سلطعون"],
    "Seeds": ["sesame", "tahini", "chia", "flaxseed", "سمسم", "طحينة", "شيا"],
    "Legumes": ["lentil", "chickpea", "beans", "peas", "عدس", "حمص", "فاصوليا", "بازلاء"],
    "Mustard": ["mustard", "خردل", "مستردة"],
    "Sulphites": ["sulphite", "sulfite", "sulfur dioxide", "E220", "E221", "كبريتات", "ثاني أكسيد الكبريت"],
    "Celery": ["celery", "كرفس"],
    "Corn": ["corn", "maize", "starch", "fructose", "ذرة", "نشا"]
}

@router.get("/analyze/{barcode}")
async def analyze_barcode(barcode: str, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):

    product = db.query(Product).filter(Product.barcode == barcode).first()

    if not product:
        raise HTTPException(status_code=404, detail="المنتج غير موجود في قاعدة بيانات SafeBite")

    user_allergy_names = [ua.allergy.allergy_type for ua in current_user.allergies if ua.allergy]
    user_allergy_ids = {ua.allergy_id for ua in current_user.allergies if ua.allergy_id}

    detected_allergens = []
    ingredients_lower = (product.ingredients or "").lower()

    product_allergy_ids = {pa.allergy_id for pa in product.allergies}
    conflicting_ids = user_allergy_ids.intersection(product_allergy_ids)

    if conflicting_ids:
        danger_list = db.query(Allergy).filter(Allergy.allergy_id.in_(conflicting_ids)).all()
        detected_allergens.extend([a.allergy_type for a in danger_list])

    for allergy_name in user_allergy_names:
        if allergy_name not in detected_allergens:
            keywords = ALLERGY_KEYWORDS.get(allergy_name, [allergy_name.lower()])
            if any(word in ingredients_lower for word in keywords):
                detected_allergens.append(allergy_name)

    is_safe = len(detected_allergens) == 0
    result_status = "SAFE" if is_safe else "DANGER"

    if is_safe:
        danger_info = "Safe for your profile ✅"
    else:
        danger_info = f"Warning: Contains components linked to your {', '.join(detected_allergens)} allergy."

    product_alternatives = product.alternatives if product.alternatives else ""

    try:
        new_scan = ScanHistory(
            user_id=current_user.user_id,
            barcode=barcode,
            product_id=product.product_id,
            result=result_status,
            danger_info=danger_info
        )
        db.add(new_scan)
        db.commit()
        db.refresh(new_scan)
    except Exception as e:
        db.rollback()
        print(f"History Save Error: {e}")

    return {
        "success": True,
        "product": {
            "name": product.product_name,
            "brand": product.brand,
            "ingredients": product.ingredients,
            "is_safe": is_safe,
            "allergens_found": detected_allergens,
            "danger_info": danger_info,
            "alternatives": product_alternatives  # إرسال النص من الداتابيز
        }
    }

@router.get("/history")
async def get_user_history(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    history = db.query(ScanHistory).filter(
        ScanHistory.user_id == current_user.user_id
    ).order_by(ScanHistory.scanned_at.desc()).all()

    return [{
        "scan_id": item.scan_id,
        "product_name": item.product.product_name if item.product else f"Barcode: {item.barcode}",
        "result": item.result,
        "danger_info": item.danger_info,
        "scanned_at": item.scanned_at
    } for item in history]
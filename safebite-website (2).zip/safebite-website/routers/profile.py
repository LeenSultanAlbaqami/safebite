"""
SafeBite — Profile Router
Manages the retrieval/updates of User Profiles and Scan History.
Ensures frontend requests for /profile/me and /profile/history are handled.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from database import get_db
from models import User, UserAllergy, ScanHistory
from schemas import UserOut, ProfileUpdateRequest, ScanHistoryOut
from security import get_current_user
from routers.auth import _build_user_out, _get_or_create_allergy

router = APIRouter(prefix="/profile", tags=["Profile"])


@router.get("/me", response_model=UserOut)
def get_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Returns the authenticated user's profile including linked allergies."""
    user = db.query(User).options(
        joinedload(User.allergies).joinedload(UserAllergy.allergy)
    ).filter(User.user_id == current_user.user_id).first()

    if not user:
        raise HTTPException(status_code=404, detail="Profile not found")
    return _build_user_out(user)


@router.get("/history", response_model=list[ScanHistoryOut])
def get_scan_history(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Retrieves the list of previous food scans performed by the user."""
    rows = db.query(ScanHistory).filter(
        ScanHistory.user_id == current_user.user_id
    ).order_by(ScanHistory.scanned_at.desc()).all()

    return [
        ScanHistoryOut(
            scan_id=row.scan_id,
            barcode=row.barcode,
            product_name=row.product.product_name if row.product else "Unknown",
            result=row.result,
            danger_info=row.danger_info,
            scanned_at=row.scanned_at
        ) for row in rows
    ]


@router.put("/update", response_model=UserOut)
def update_profile(body: ProfileUpdateRequest, current_user: User = Depends(get_current_user),
                   db: Session = Depends(get_db)):
    """Updates profile details and refreshes allergy associations."""
    user = db.query(User).filter(User.user_id == current_user.user_id).first()

    fields = ["full_name", "age", "phone_number", "gender", "severity_level",
              "reaction_symptoms", "dietary_lifestyle", "other_diet_notes", "risk_management"]

    for field in fields:
        val = getattr(body, field, None)
        if val is not None:
            setattr(user, field, val)

    if body.allergies is not None:
        db.query(UserAllergy).filter(UserAllergy.user_id == user.user_id).delete()
        for name in body.allergies:
            if name.strip():
                allergy = _get_or_create_allergy(db, name)
                db.add(UserAllergy(user_id=user.user_id, allergy_id=allergy.allergy_id))

    db.commit()
    db.refresh(user)
    return _build_user_out(user)